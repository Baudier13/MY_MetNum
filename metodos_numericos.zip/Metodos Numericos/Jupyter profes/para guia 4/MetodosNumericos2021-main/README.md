# MetodosNumericos2021
Guias y Env. para la materia. Versión Julia
