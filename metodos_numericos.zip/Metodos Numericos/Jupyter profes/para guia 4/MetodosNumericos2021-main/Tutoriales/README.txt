Extraido de
  https://cheatography.com/jonathan992/cheat-sheets/gnu-linux-command-spanish/
